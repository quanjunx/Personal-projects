package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * @author quanjunx 根据page,pagelist显示project
 */
public class ProjectListShowing implements PagedDataOutputAdapter {

	@Override
	public Map<String, Object> getPagedData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		// 连接数据库
		crud.setCon(con);
		// 查询数据库，返回project数据
		Long page = Long.parseLong(params.get("page")[0]);
		Long pageSize = Long.parseLong(params.get("pagesize")[0]);
		String sortName = "begin";
		if(params.get("sortname")[0]!=null){
			sortName = params.get("sortname")[0];
		}
		
		String sortOrder="asc";
		if(params.get("sortorder")!=null){
			sortOrder = params.get("sortorder")[0];
		}
		StringBuffer sb = new StringBuffer(
				"SELECT id,name,begin,end,state FROM project ");
		sb.append(" ORDER BY ");
		sb.append(sortName);
		sb.append(" " + sortOrder);
		sb.append(" LIMIT ");
		sb.append((page - 1) * pageSize);
		sb.append(",");
		sb.append(pageSize);
		System.out.println(sb.toString());
		List<Map<String, Object>> result = crud.query(sb.toString());
		long total = (Long) crud.queryOne(
				"SELECT count(id) AS total FROM project").get("total");
		Map<String, Object> r = new HashMap<String, Object>();
		r.put("Rows", result);
		r.put("Total", total);
		return r;
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
			params.put("page", new String[] { "1" });
			params.put("pagesize", new String[] { "2" });
			params.put("sortname", new String[] { "begin" });
			params.put("sortorder", new String[] { "asc" });

			Map<String, Object> result = new ProjectListShowing()
					.getPagedData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
