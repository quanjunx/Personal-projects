package org.ez.adapter;

import java.util.Map;

/**
 * @author Jaon
 * 用来生成验证码的适配器
 */
public interface IdentifingCodeAdapter {
	
	/**
	 * @return
	 * 返回的Map包括2项
	 * code：随机生成的验证码
	 * image:验证码图片的base64编码后的字符串
	 */
	public Map<String,String> createIdentifingCode();
}
