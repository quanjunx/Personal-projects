package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * 
 * @author quanjunx 
 * 15.项目投入汇总
 */
public class TotalProConsuming implements PagedDataOutputAdapter {

	public Map<String, Object> getPagedData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		// 连接数据库
		crud.setCon(con);

		Long page = Long.parseLong(params.get("page")[0]);
		Long pageSize = Long.parseLong(params.get("pagesize")[0]);
		String sortName = params.get("sortname")[0];
		String sortOrder = params.get("sortorder")[0];
		String begins = params.get("begins")[0];
		String ends = params.get("ends")[0];
		String pro_ids = params.get("pro_ids")[0];
		StringBuffer sb = new StringBuffer();
		// 判断begin,end,pro_id的存在情况，并分别作出相应处理
		if (begins != null && ends != null && pro_ids != null) {// (1)b,e,p都存在
			sb = new StringBuffer("SELECT dep_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%' AND end LIKE '%ends%' AND pro_id LIKE '%pro_ids%'");
			System.out.println(sb.toString());
		}

		if (begins == null && ends == null && pro_ids == null) {// (2)b,e,p都不存在
			System.out.println("搜索条件不能为空，请输入相关信息！");
		}

		if (begins != null && ends == null && pro_ids == null) {// (3)b存在,e,p不存在
			sb = new StringBuffer("SELECT dep_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%'");
			System.out.println(sb.toString());
		}

		if (begins == null && ends != null && pro_ids == null) {// (4)e存在,b,p不存在
			sb = new StringBuffer("SELECT dep_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE end LIKE '%ends%'");
			System.out.println(sb.toString());
		}

		if (begins == null && ends == null && pro_ids != null) {// (5)p存在,b,e不存在
			sb = new StringBuffer("SELECT dep_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE pro_id LIKE '%pro_ids%'");
			System.out.println(sb.toString());
		}

		if (begins != null && ends != null && pro_ids == null) {// (6)b,e存在,p不存在
			sb = new StringBuffer("SELECT dep_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%' AND end LIKE '%ends%'");
			System.out.println(sb.toString());
		}

		if (begins != null && ends == null && pro_ids != null) {// (7)b,p存在,e不存在
			sb = new StringBuffer("SELECT dep_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%' AND pro_id LIKE '%pro_ids%'");
			System.out.println(sb.toString());
		}

		if (begins == null && ends != null && pro_ids != null) {// (8)e,p存在,b不存在
			sb = new StringBuffer("SELECT dep_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE end LIKE '%ends%' AND pro_id LIKE '%pro_ids%'");
			System.out.println(sb.toString());
		}

		List<Map<String, Object>> result = crud.query(sb.toString());
		long total = (Long) crud.queryOne(
				"SELECT count(id) AS total FROM dailyreport").get("total");
		Map<String, Object> r = new HashMap<String, Object>();
		r.put("Rows", result);
		r.put("Total", total);
		return r;
	}

}
