package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * 
 * @author quanjunx 
 * 11.个人日报工作量查询—按项目
 */
public class PersonalDRWorkloadQueryByPro implements PagedDataOutputAdapter {

	@Override
	public Map<String, Object> getPagedData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		List<Object> list = new ArrayList<Object>();
		Long page = Long.parseLong(params.get("page")[0]);
		Long pageSize = Long.parseLong(params.get("pagesize")[0]);
		String sortName = "date";
		if(params.get("sortname")[0]!=null){
			sortName = params.get("sortname")[0];
		}
		
		String sortOrder="desc";
		if(params.get("sortorder")!=null){
			sortOrder = params.get("sortorder")[0];
		}
		StringBuffer sb = new StringBuffer(
				"SELECT pro_name AS project,workload,overtime FROM dailyreport ");
		String condition = getCondition(list, params);
		sb.append(condition);
		crud.setCon(con);
		System.out.println(sb.toString());
		List<Map<String, Object>> rows = crud.query(sb.toString(),
				list.toArray());
		sb = new StringBuffer("SELECT count(id) AS total FROM dailyreport");
		sb.append(condition);
		System.out.println(sb.toString());
		long total = (Long) crud.queryOne(sb.toString(), list.toArray()).get(
				"total");
		Map<String,Object> result = new HashMap<String, Object>();
		result.put("Rows", rows);
		result.put("Total", total);
		return result;
	}

	public String getCondition(List<Object> list, Map<String, String[]> params) {
		StringBuffer sb = new StringBuffer(" WHERE 1=1");
		if (params.get("person_id") != null) {
			list.add("%" + params.get("person_id")[0] + "%");
			sb.append(" AND person_id LIKE ?");
		}
		if (params.get("begin") != null) {
			list.add(params.get("begin")[0]);
			sb.append(" AND date>=?");
		}
		if (params.get("end") != null) {
			list.add(params.get("end")[0]);
			sb.append(" AND date<=?");
		}
	
		
		System.out.println(sb.toString());
		
		return sb.toString();
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
			params.put("page", new String[] { "1" });
			params.put("pagesize", new String[] { "2" });
			params.put("sortname", new String[] { "id" });
			params.put("sortorder", new String[] { "asc" });
			params.put("person_id", new String[]{"S1"});

			Map<String, Object> result = new PersonalDRWorkloadQueryByPro()
					.getPagedData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}