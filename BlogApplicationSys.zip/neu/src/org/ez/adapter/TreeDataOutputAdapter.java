package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * @author Jason
 * 以树的形式输出数据库操作结果的抽象适配器
 * 所有支持前台树格式输出的类必须实现此接口
 * 其中getTreeData返回的Map类型应该具有以下格式 
 * [
 * 		{id:1,name:'xx',parent_department:0,remarks:"yyy",ischecked:true},			//
 * 		{id:1,name:'xx',parent_department:1,remarks:"yyy"},
 * 		......//当ischecked值为false时，ischecked一项可以省略（也可以保留）
 * 		
 * ]     						
 * 
 */
public interface TreeDataOutputAdapter {
	public List<Map<String,Object>> getTreeData(CRUD crud,Connection con,
			Map<String,String[]> params) throws SQLException,Exception;

}
