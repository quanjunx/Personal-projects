package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.ez.crud.CRUD;
/**
 * 
 * @author quanjunx
 *部门未写日报查询
 */
public class DepUnwritenDRQuery implements PagedDataOutputAdapter {

	@Override
	public Map<String, Object> getPagedData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
