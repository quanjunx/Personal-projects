package org.ez.adapter;

import it.sauronsoftware.base64.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import nl.captcha.Captcha;

public class TransmitCode implements IdentifingCodeAdapter {

	/* (non-Javadoc)
	 * @see org.ez.adapter.IdentifingCodeAdapter#createIdentifingCode()
	 * 继承IdentifingCodeAdapter借口，重写唯一的方法
	 * 能够产生最基本的验证码（以base64的形式返回，同时返回验证码的字符串表示。
	 */
	@Override
	public Map<String, String> createIdentifingCode() {
		Captcha captcha = new Captcha.Builder(200, 50).addText().build();
		String answer = captcha.getAnswer();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Map<String, String> map = new HashMap<String, String>();
		try {
			ImageIO.write(captcha.getImage(), "PNG", baos);
			byte[] bytes = Base64.encode(baos.toByteArray());			
			map.put("code", answer);
			map.put("image", new String(bytes, "US-ASCII"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}
}
