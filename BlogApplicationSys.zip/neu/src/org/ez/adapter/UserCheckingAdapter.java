package org.ez.adapter;

import java.sql.Connection;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * @author Jason
 * 
 */
public interface UserCheckingAdapter {
	/**
	 * @param crud    crud接口用来对数据库操作
	 * @param con	  数据库连接对象
	 * @param user    从客户来的用户名明文
	 * @param password   从客户来的密码明文
	 * @return   验证用户成功后，返回这个用户的必要信息
	 * 			包括：
	 * 			id：这个用户的id
	 * 			name:这个用户的姓名
	 * 			depart_id:这个用户所在的部门id
	 * 			depart_name:部门名称
	 * 			is_leader:是否是领导
	 * 			role_id:他的角色id
	 * 			role_name:他的角色名
	 * @throws Exception 当验证失败则抛出异常  
	 */
	public Map<String,Object> check(CRUD crud,Connection con,String user,String password)
			throws Exception;
}
