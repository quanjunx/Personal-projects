package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
import org.jasypt.util.password.BasicPasswordEncryptor;

/**
 * @see org.ez.adapter.UserCheckingAdapter
 * @author quanjunx 继承UserCheckingAdapter接口，重写唯一的方法 验证用户信息，若信息相匹配则登录成功
 */
public class UserChecking implements UserCheckingAdapter {

	@Override
	public Map<String, Object> check(CRUD crud, Connection con, String user,
			String password) throws Exception {
		//连接数据库
		crud.setCon(con); 
		//生成一个Map对象，通过用户名，查找并返回personlogin中的一条记录
		Map<String, Object> result = crud.queryOne(
				"SELECT * FROM personlogin WHERE user=?", user);
		//如果用户名不存在，则抛出异常，若存在则执行下一步（检测密码）
		if (result == null) {
			throw new Exception("login failure!");
		}
		//加密明文密码
		BasicPasswordEncryptor passwordEncryptor = new BasicPasswordEncryptor();
		//检测加密后的密文密码和原有明文密码是否匹配，如果匹配则登录成功，否则抛出异常
		if (passwordEncryptor.checkPassword(password, (String)result.get("pass"))) {
			result.remove("user");
			result.remove("pass");
			return result;
		} else {
			throw new Exception("login failure!");
		}
	}

	public static void main(String[] args) {
		try {
			Map<String,Object> result = new UserChecking()
					.check(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), "admin", "123456");
		System.out.println("Rows:"+result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
