package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * 
 * @author quanjunx 
 * 18.部门投入汇总
 */
public class DepTotalConsumption implements PagedDataOutputAdapter {

	@Override
	public Map<String, Object> getPagedData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		// 连接数据库
		crud.setCon(con);

		Long page = Long.parseLong(params.get("page")[0]);
		Long pageSize = Long.parseLong(params.get("pagesize")[0]);
		String sortName = params.get("sortname")[0];
		String sortOrder = params.get("sortorder")[0];
		String begins = params.get("begins")[0];
		String ends = params.get("ends")[0];
		String dep_ids = params.get("dep_ids")[0];
		StringBuffer sb = new StringBuffer();
		// 判断begin,end,dep_id的存在情况，并分别作出相应处理
		if (begins != null && ends != null && dep_ids != null) {// (1)b,e,d都存在
			sb = new StringBuffer(
					"SELECT person_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%' AND end LIKE '%ends%' AND dep_id LIKE '%dep_ids%'");
			// System.out.println(sb.toString());
		}

		if (begins == null && ends == null && dep_ids == null) {// (2)b,e,d都不存在
			System.out.println("搜索条件不能为空，请输入相关信息！");
		}

		if (begins != null && ends == null && dep_ids == null) {// (3)b存在,e,d不存在
			sb = new StringBuffer(
					"SELECT person_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%'");
			// System.out.println(sb.toString());
		}

		if (begins == null && ends != null && dep_ids == null) {// (4)e存在,b,d不存在
			sb = new StringBuffer(
					"SELECT person_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE end LIKE '%ends%'");
			// System.out.println(sb.toString());
		}

		if (begins == null && ends == null && dep_ids != null) {// (5)d存在,b,e不存在
			sb = new StringBuffer(
					"SELECT person_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE dep_id LIKE '%dep_ids%'");
			// System.out.println(sb.toString());
		}

		if (begins != null && ends != null && dep_ids == null) {// (6)b,e存在,d不存在
			sb = new StringBuffer(
					"SELECT person_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%' AND end LIKE '%ends%'");
			// System.out.println(sb.toString());
		}

		if (begins != null && ends == null && dep_ids != null) {// (7)b,d存在,e不存在
			sb = new StringBuffer(
					"SELECT person_name FROM dailyreport ");
			sb.append(" ORDER BY ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE begin LIKE '%begins%' AND dep_id LIKE '%dep_ids%'");
			// System.out.println(sb.toString());
		}

		if (begins == null && ends != null && dep_ids != null) {// (8)e,d存在,b不存在
			sb = new StringBuffer(
					"SELECT person_name FROM dailyreport ");
			sb.append(sortName);
			sb.append(" " + sortOrder);
			sb.append(" LIMIT ");
			sb.append((page - 1) * pageSize);
			sb.append(",");
			sb.append(pageSize);
			sb.append("WHERE end LIKE '%ends%' AND dep_id LIKE '%dep_ids%'");
			// System.out.println(sb.toString());
		}

		List<Map<String, Object>> result = crud.query(sb.toString());
		long total = (Long) crud.queryOne(
				"SELECT count(id) AS total FROM dailyreport").get("total");
		Map<String, Object> r = new HashMap<String, Object>();
		r.put("Rows", result);
		r.put("Total", total);
		return r;
	}

}
