package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * @author Jason
 * 以一列的形式输出数据库操作结果的抽象适配器
 * 所有支持前台一列格式输出的类必须实现此接口
 * 其中getOneColumnData返回的List类型应该具有以下格式 
 * [
 * 		{id:1,text:'xx'},			//id和text这两个键是必须包含的项，并且名字也必须是id和text
 * 		{id:2,text:'yy'}
 * ]     						
 * 
 */
public interface OneColumnDataOutputAdapter {
	
	public List<Map<String,Object>> getOneColumnData(CRUD crud,Connection con,
									Map<String,String[]> params) throws SQLException,Exception;
}