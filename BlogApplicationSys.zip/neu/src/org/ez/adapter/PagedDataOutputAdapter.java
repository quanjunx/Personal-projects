package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * @author Jason
 * 以分页的形式输出数据库操作结果的抽象适配器
 * 所有支持前台分页格式输出的类必须实现此接口
 * 其中getPagedData返回的Map类型应该具有以下格式
 * {
 *     Rows:[{id:1,name:'xx'},{id:2,name:'yy'}],     //List类型，代表数据库返回结果中每行数据的列表集合
 *     Total:15672     								 //数据库中符合查询结果的数据总数，注意这里是总数，
 *     												 //Rows返回的不一定是所有行的结果的集合，因为可能分页
 *     												 //但是Total返回的一定是符合条件的总数
 *     												 //字段名不必一定是id，name，也不必一定是2个
 * }
 */
public interface PagedDataOutputAdapter {
	
	public Map<String,Object> getPagedData(CRUD crud,Connection con,Map<String,String[]> params) 
												throws SQLException,Exception;

}