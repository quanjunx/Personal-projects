package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *为项目配置部门
 */
public class SetDepForPro implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		int r = 0;
		String[] pro_ids = params.get("pro_id");
		String[] dep_ids = params.get("dep_id");
		for (int i = 0; i < pro_ids.length; i++) {
			r = crud.update(
					"INSERT INTO project_department(pro_id,dep_id) VALUES(?,?)",
					pro_ids[i], dep_ids[i]);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();

		params.put("pro_id", new String[] { "EZCMS","Canteens" });
		params.put("dep_id", new String[] { "4","1" });
		new SetDepForPro().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}

