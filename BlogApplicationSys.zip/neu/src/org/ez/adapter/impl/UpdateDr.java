package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *以当前用户身份修改一篇日报
 */
public class UpdateDr implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		int r = crud
				.update("UPDATE dailyreport SET date=?,task=?,workload=?,overtime=?,pro_id=?,prp_id=?,tomorrow=? WHERE id=?",
						params.get("date")[0], params.get("task")[0],
						params.get("workload")[0], params.get("overtime")[0],
						params.get("pro_id")[0], params.get("prp_id")[0],
						params.get("tomorrow")[0],params.get("dr_id")[0]);

		Map<String, Object> map = new HashMap<String, Object>();
		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("date", new String[] { "2012-04-22" });
		params.put("task", new String[] { "study" });
		params.put("workload", new String[] { "1.1" });
		params.put("overtime", new String[] { "1.2" });
		params.put("pro_id", new String[] { "Canteens" });
		params.put("prp_id", new String[] { "3" });
		params.put("tomorrow", new String[] { "asd" });
		params.put("dr_id", new String[] { "2" });
		new UpdateDr().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
