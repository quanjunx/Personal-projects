package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *2.修改PRP阶段信息（一个或批量）
 */
public class UpdatePRP implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		String[] abbs = params.get("abb");
		String[] names = params.get("name");
		String[] remarks = params.get("remarks");
		String[] ids = params.get("id");
		int r1=0,r2=0;
		for (int i = 0; i < abbs.length; i++) {
			r1=crud.update(
					"UPDATE prp SET abbreviation=?,name=?,remarks=? WHERE id=?",
					abbs[i], names[i], remarks[i],ids[i]);
			r2=crud.update(
					"UPDATE dailyreport SET prp_name=? WHERE prp_id=?",
					names[i], ids[i]);
		}

		Map<String, Object> map = new HashMap<String, Object>();
		int r = r1 + r2;
		if (r == 2) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("abb", new String[] { "Milans","Juvens" });
		params.put("name", new String[] { "Bobo","Der"});
		params.put("remarks", new String[] { "mytest","Kaka" });
		params.put("id", new String[] { "13","14" });
		new UpdatePRP().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
