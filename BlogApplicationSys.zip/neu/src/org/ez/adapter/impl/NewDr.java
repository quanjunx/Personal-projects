package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * 
 * @author quanjunx 以当前用户身份增加一篇日报
 */
public class NewDr implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		int r = crud
				.update("INSERT INTO dailyreport(date,task,workload,overtime,pro_id,prp_id,tomorrow,pro_name,prp_name,person_id,person_name,check_date,check_person_id,check_person_name,deny_reason,dep_id,dep_name) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
						params.get("date")[0], params.get("task")[0],
						params.get("workload")[0], params.get("overtime")[0],
						params.get("pro_id")[0], params.get("prp_id")[0],
						params.get("tomorrow")[0], "default1","default2","S999","dada","2012-4-29","999","Jason","nothing",9,"Test");
		Map<String, Object> map = new HashMap<String, Object>();
		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();

		params.put("date", new String[] { "2012-04-27" });
		params.put("task", new String[] { "test" });
		params.put("workload", new String[] { "1.5" });
		params.put("overtime", new String[] { "2.0" });
		params.put("pro_id", new String[] { "Test" });
		params.put("prp_id", new String[] { "3" });
		params.put("tomorrow", new String[] { "nothing" });
		new NewDr().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
