package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *为项目配置人员（一个或多个）
 */
public class SetPersonForPro implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		int r = 0;
		String[] pro_ids = params.get("pro_id");
		String[] person_ids = params.get("person_id");
		String[] dignitys = params.get("dignity");
		for (int i = 0; i < pro_ids.length; i++) {
			r = crud.update(
					"INSERT INTO project_person(pro_id,person_id,dignity) VALUES(?,?,?)",
					pro_ids[i], person_ids[i],
					dignitys[i]);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();

		params.put("pro_id", new String[] { "DailyReport","Canteens" });
		params.put("person_id", new String[] { "S2","S1" });
		params.put("dignity", new String[] { "L","B" });
		new SetPersonForPro().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
