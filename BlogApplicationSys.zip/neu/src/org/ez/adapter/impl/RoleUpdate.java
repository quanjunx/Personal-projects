package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *角色增加、删除、修改
 */
public class RoleUpdate implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		int r = 0, r1 = 0, r2 = 0;
		String[] id1s = params.get("id1");
		String[] id2s = params.get("id2");
		String[] names = params.get("name");
		Map<String, Object> map = new HashMap<String, Object>();
		if (params.get("action")[0] == "i") {
			for (int t = 0; t < id1s.length; t++) {
				r = crud.update(
						"INSERT INTO role(name) VALUES(?)",
						names[t]);
			}

			if (r == 1) {
				map.put("result", "success");
			} else {
				map.put("result", "failure");
			}
			con.commit();
		}
		if (params.get("action")[0] == "u") {
			for (int t = 0; t < id1s.length; t++) {
				r1 = crud
						.update("UPDATE role SET id = ?,name = ? WHERE id = ?",
								id1s[t], names[t], id2s[t]);
				r2 = crud.update(
						"UPDATE role_priviledge SET role_id = ? WHERE role_id = ?",
						id1s[t],id2s[t]);
				r = r1 + r2;
				if (r == 2) {
					map.put("result", "success");
				} else {
					map.put("result", "failure");
				}
				con.commit();

			}
		}
		if (params.get("action")[0] == "d") {
			for (int t = 0; t < id2s.length; t++) {
				r1 = crud
						.update("DELETE FROM role WHERE id = ?",
								id2s[t]);
				r2 = crud.update(
						"DELETE FROM role_priviledge WHERE role_id = ?",
						id2s[t]);
				r = r1 + r2;
				if (r == 2) {
					map.put("result", "success");
				} else {
					map.put("result", "failure");
				}
				con.commit();

			}
		}

		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();

		params.put("id1", new String[] { "999" });
		params.put("id2", new String[] { "999" });
		params.put("name", new String[] { "examined" });
		params.put("action", new String[] { "d" });
		new RoleUpdate().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
