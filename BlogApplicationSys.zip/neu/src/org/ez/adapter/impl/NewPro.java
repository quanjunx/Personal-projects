package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * 
 * @author quanjunx 新增项目（一个或批量）
 */
public class NewPro implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		int r = 0;
		String[] ids = params.get("id");
		String[] names = params.get("name");
		String[] remarks = params.get("remarks");
		String[] begins = params.get("begin");
		String[] ends = params.get("end");
		for (int i = 0; i < ids.length; i++) {
			r = crud.update(
					"INSERT INTO project(id,name,des,begin,end,state) VALUES(?,?,?,?,?,?)",
					ids[i], names[i],
					remarks[i], begins[i],
					ends[i], 1);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();

		params.put("id", new String[] { "Esou","Blog" });
		params.put("name", new String[] { "test1","test2" });
		params.put("remarks", new String[] { "mytest1","mytest2" });
		params.put("begin", new String[] { "2012-04-20","2012-04-21" });
		params.put("end", new String[] { "2012-04-25","2012-04-26" });
		new NewPro().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
