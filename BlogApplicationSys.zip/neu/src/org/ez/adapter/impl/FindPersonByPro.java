package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.ez.adapter.TreeDataOutputAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *根据项目列出所有参加该项目的员工
 */
public class FindPersonByPro implements TreeDataOutputAdapter {

	@Override
	public List<Map<String,Object>> getTreeData(CRUD crud,Connection con,
			Map<String,String[]> params) throws SQLException,Exception{
		crud.setCon(con);	// 查询数据库
		String sortName = "id";
		if(params.get("sortname")[0]!=null){
			sortName = params.get("sortname")[0];
		}
		
		String sortOrder="asc";
		if(params.get("sortorder")!=null){
			sortOrder = params.get("sortorder")[0];
		}
		String proID = params.get("pro_id")[0];
		StringBuffer sb = new StringBuffer(
				"SELECT distinct id AS person_id, personlogin.name,dignity FROM personlogin,project_person  WHERE personlogin.id = project_person.person_id and project_person.pro_id LIKE ?");
		sb.append(" ORDER BY ");
		sb.append(sortName);
		sb.append(" " + sortOrder);
		List<Map<String, Object>> r = crud.query(sb.toString(),"%"+proID+"%");
		return r;
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
			params.put("sortname", new String[] { "id" });
			params.put("sortorder", new String[] { "asc" });
			params.put("pro_id", new String[] { "Daily" });

			List<Map<String, Object>> result = new FindPersonByPro()
					.getTreeData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
