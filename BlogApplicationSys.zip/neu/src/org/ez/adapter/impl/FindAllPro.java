package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ez.adapter.ListDataOutputAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *9.列出系统所有状态（运行，挂起，关闭）的项目
 */
public class FindAllPro implements ListDataOutputAdapter {

	@Override
	public Map<String, Object> getListData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		crud.setCon(con);	// 查询数据库
		
		String sortName = "id";
		if(params.get("sortname")[0]!=null){
			sortName = params.get("sortname")[0];
		}
		
		String sortOrder="asc";
		if(params.get("sortorder")!=null){
			sortOrder = params.get("sortorder")[0];
		}
		StringBuffer sb = new StringBuffer(
				"SELECT id AS value,name FROM project");
		sb.append(" ORDER BY ");
		sb.append(sortName);
		sb.append(" " + sortOrder);
		
		//System.out.println(sb.toString());
		List<Map<String, Object>> result = crud.query(sb.toString());
		Map<String, Object> r = new HashMap<String, Object>();
		r.put("list", result);
		return r;
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
		
			params.put("sortname", new String[] { "id" });
			params.put("sortorder", new String[] { "asc" });

			Map<String, Object> result = new FindAllPro()
					.getListData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
