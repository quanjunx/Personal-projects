package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * 
 * @author quanjunx 修改项目（一个或批量）
 */
public class UpdatePro implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		String[] id1s = params.get("id1");
		String[] names = params.get("name");
		String[] remarks = params.get("remarks");
		String[] begins = params.get("begin");
		String[] ends = params.get("end");
		String[] states = params.get("state");
		String[] id2s = params.get("id2");
		int r1 = 0, r2 = 0, r3 = 0, r4 = 0, r5 = 0,r6 = 0;
		for (int i = 0; i < id1s.length; i++) {
			r1 = crud
					.update("UPDATE project SET id=?,name=?,des=?,begin=?,end=?,state=? WHERE id=?",
							id1s[i], names[i],
							remarks[i], begins[i],
							ends[i], states[i],
							id2s[i]);
			r2 = crud.update(
					"UPDATE project_department SET pro_id=? WHERE pro_id=?",
					id1s[i], id2s[i]);
			r3 = crud.update(
					"UPDATE project_person SET pro_id=? WHERE pro_id=?",
					id1s[i], id2s[i]);
			r4 = crud.update("UPDATE project_prp SET pro_id=? WHERE pro_id=?",
					id1s[i], id2s[i]);
			r5 = crud
					.update("UPDATE dailyreport SET pro_id=?,pro_name=? WHERE pro_id=?",
							id1s[i], names[i],
							id2s[i]);
			r6 = crud.update("UPDATE project_person SET pro_id=? WHERE pro_id=?",
					id1s[i], id2s[i]);
		}

		Map<String, Object> map = new HashMap<String, Object>();
		int r = r1 + r2 + r3 + r4 + r5 + r6;
		if (r == 6) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("id1", new String[] { "Canteens","wasd" });
		params.put("name", new String[] { "食堂售饭","sth" });
		params.put("remarks", new String[] { "j2ee","javaweb" });
		params.put("begin", new String[] { "2012-04-20","2012-04-21" });
		params.put("end", new String[] { "2012-04-26","2012-04-27" });
		params.put("state", new String[] { "1","1" });
		params.put("id2", new String[] { "Canteen","asd" });
		new UpdatePro().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
