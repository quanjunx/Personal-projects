package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.ez.adapter.TreeDataOutputAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * 
 * @author quanjunx 2.列出所有已被该项目配置的部门，数据以树形形式输出
 */
public class DepListByPro implements TreeDataOutputAdapter {

	@Override
	public List<Map<String,Object>> getTreeData(CRUD crud,Connection con,
			Map<String,String[]> params) throws SQLException,Exception{
		crud.setCon(con);	// 查询数据库
		String sortName = "id";
		if(params.get("sortname")[0]!=null){
			sortName = params.get("sortname")[0];
		}
		
		String sortOrder="asc";
		if(params.get("sortorder")!=null){
			sortOrder = params.get("sortorder")[0];
		}
		String proID = params.get("pro_id")[0];
		StringBuffer sb = new StringBuffer(
				"SELECT id ,name,parent_department,remarks FROM department");
		sb.append(" ORDER BY ");
		sb.append(sortName);
		sb.append(" " + sortOrder);
		List<Map<String, Object>> r = crud.query(sb.toString());
		List<Object> depList = new QueryRunner().query(con, "SELECT dep_id FROM project_department WHERE pro_id=?", new ColumnListHandler(), proID);
		Set<Object> depSet = new HashSet<Object>(depList);
		for(Map<String,Object> map:r){
			if(depSet.contains(map.get("id"))){
				map.put("ischecked", true);
			}
		}
		return r;
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
			params.put("sortname", new String[] { "id" });
			params.put("sortorder", new String[] { "asc" });
			params.put("pro_id", new String[] { "Canteen" });

			List<Map<String, Object>> result = new DepListByPro()
					.getTreeData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
