package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.ez.adapter.TreeDataOutputAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *1.列出所有部门，数据以树形形式输出
 */
public class DepList implements TreeDataOutputAdapter {

	@Override
	public List<Map<String,Object>> getTreeData(CRUD crud,Connection con,
			Map<String,String[]> params) throws SQLException,Exception{
		crud.setCon(con);	// 查询数据库
		String sortName = "id";
		if(params.get("sortname")[0]!=null){
			sortName = params.get("sortname")[0];
		}
		
		String sortOrder="asc";
		if(params.get("sortorder")!=null){
			sortOrder = params.get("sortorder")[0];
		}
		StringBuffer sb = new StringBuffer(
				"SELECT id ,name,parent_department,remarks FROM department");
		sb.append(" ORDER BY ");
		sb.append(sortName);
		sb.append(" " + sortOrder);
		
		List<Map<String, Object>> r = crud.query(sb.toString());
		return r;
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
			params.put("sortname", new String[] { "id" });
			params.put("sortorder", new String[] { "asc" });

			List<Map<String, Object>> result = new DepList()
					.getTreeData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
