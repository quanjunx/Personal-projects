package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * 
 * @author quanjunx 以当前用户身份删除一篇或多篇日报
 */
public class DeleteDr implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		String[] ids = params.get("id");
		int r = 0;
		for (int i = 0; i < ids.length; i++) {
			r = crud.update("DELETE FROM dailyreport WHERE id=?", ids[i]);
		}

		Map<String, Object> map = new HashMap<String, Object>();

		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("id", new String[] { "2","3" });
		new DeleteDr().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
