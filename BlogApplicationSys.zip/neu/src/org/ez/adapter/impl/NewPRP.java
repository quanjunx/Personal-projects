package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;

/**
 * 
 * @author quanjunx 1.新增PRP(一个或批量)
 */
public class NewPRP implements UpdateResultAdapter {
	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		int r = 0;
		String[] abbs = params.get("abb");
		String[] names = params.get("name");
		String[] remarks = params.get("remarks");
		for (int i = 0; i < abbs.length; i++) {
			r = crud.update(
					"INSERT INTO prp(abbreviation,name,remarks) VALUES(?,?,?)",
					abbs[i], names[i], remarks[i]);
		}

		Map<String, Object> map = new HashMap<String, Object>();
		
		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("abb", new String[] { "Linear", "Bitter" });
		params.put("name", new String[] { "test1", "test2" });
		params.put("remarks", new String[] { "mytest1", "mytest2" });
		new NewPRP().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
