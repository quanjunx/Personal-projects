package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ez.adapter.ListDataOutputAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *4.列出当前用户的所有下属
 */
public class FindSubordinate implements ListDataOutputAdapter {

	@Override
	public Map<String, Object> getListData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		String personID = params.get("id")[0];
		StringBuffer sb = new StringBuffer(
				"select id AS value,name from personlogin where is_leader = 0 AND depart_name IN (select depart_name from personlogin where id LIKE ?)");
		/*String condition = getCondition(list, params);*/
		/*sb.append(condition);*/
		crud.setCon(con);
		System.out.println(sb.toString());
		List<Map<String, Object>> rows = crud.query(sb.toString(),"%"+personID+"%");
		Map<String,Object> result = new HashMap<String, Object>();
		result.put("list", rows);
		return result;
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
			
			params.put("sortname", new String[] { "value" });
			params.put("sortorder", new String[] { "asc" });
			params.put("id", new String[]{"L1"});

			Map<String, Object> result = new FindSubordinate()
					.getListData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
