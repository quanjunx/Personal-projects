package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.ez.adapter.UpdateResultAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *不通过一批或者一个日报
 */
public class NotPassDr implements UpdateResultAdapter {

	@Override
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		con.setAutoCommit(false);
		crud.setCon(con);
		String[] dr_ids = params.get("id");
		String[] deny_reasons = params.get("deny_reason");
		
		int r = 0;
		for (int i = 0; i < dr_ids.length; i++) {
			r = crud.update(
					"UPDATE dailyreport SET state=?,deny_reason=? WHERE id=?",
					"B",deny_reasons[i],dr_ids[i]);
		}

		Map<String, Object> map = new HashMap<String, Object>();
		if (r == 1) {
			map.put("result", "success");
		} else {
			map.put("result", "failure");
		}
		con.commit();
		return map;
	}

	public static void main(String[] args) throws SQLException, Exception {
		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("id", new String[] { "1","4" });
		params.put("deny_reason", new String[] { "Consum too much","Not a good idea" });
		new NotPassDr().getUpdateResult(new MySQLCRUD(),
				new MySQLConnectionFactory().getConnection(Privilege.ADMIN),
				params);
	}
}
