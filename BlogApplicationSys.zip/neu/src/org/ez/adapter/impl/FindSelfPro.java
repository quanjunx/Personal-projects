package org.ez.adapter.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ez.adapter.ListDataOutputAdapter;
import org.ez.crud.CRUD;
import org.ez.crud.MySQLCRUD;
import org.ez.crud.Privilege;
import org.ez.data.MySQLConnectionFactory;
/**
 * 
 * @author quanjunx
 *2.列出所有当前用户参加的且处于运行状态的项目
 */
public class FindSelfPro implements ListDataOutputAdapter {

	@Override
	public Map<String, Object> getListData(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException, Exception {
		String personID = params.get("person_id")[0];
		StringBuffer sb = new StringBuffer(
				"SELECT project.id AS value, project.name FROM project,project_person  WHERE project.state = 1 AND project_person.person_id LIKE ?");
		/*String condition = getCondition(list, params);*/
		/*sb.append(condition);*/
		crud.setCon(con);
		System.out.println(sb.toString());
		List<Map<String, Object>> rows = crud.query(sb.toString(),"%"+personID+"%");
		Map<String,Object> result = new HashMap<String, Object>();
		result.put("list", rows);
		return result;
	}

	public static void main(String[] args) {
		try {
			Map<String, String[]> params = new HashMap<String, String[]>();
			
			params.put("sortname", new String[] { "value" });
			params.put("sortorder", new String[] { "asc" });
			params.put("person_id", new String[]{"S1"});

			Map<String, Object> result = new FindSelfPro()
					.getListData(new MySQLCRUD(), new MySQLConnectionFactory()
							.getConnection(Privilege.ADMIN), params);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
