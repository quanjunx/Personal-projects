package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * @author Jason
 * 
 */
public interface UpdateResultAdapter {
	/**
	 * @param crud
	 * @param con
	 * @param params
	 * @return 返回更新结果是否成功，如果是批量更新操作，那么本次更新为一个事务 如果成功，则全部成功，如果失败则所有更新全部失败
	 * 返回的map格式为
	 * {
	 * 		result:"success"   //失败则为"failure"
	 * }
	 */
	public Map<String, Object> getUpdateResult(CRUD crud, Connection con,
			Map<String, String[]> params) throws SQLException,Exception;
}
