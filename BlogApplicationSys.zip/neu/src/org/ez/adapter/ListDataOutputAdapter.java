package org.ez.adapter;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.ez.crud.CRUD;

/**
 * @author Jason
 * 以一列的形式输出数据库操作结果的抽象适配器
 * 所有支持前台一列格式输出的类必须实现此接口
 * 其中getListData返回的Map类型应该具有以下格式 
 * {
 * 	list:[
 * 		{value:1,name:'xx'},			//value和name这两个键是必须包含的项，并且名字也必须是value和name
 * 		{value:2,name:'yy'},
 * 		......
 * 		]
 * }     						
 * 
 */
public interface ListDataOutputAdapter {
	
	public Map<String,Object> getListData(CRUD crud,Connection con,
									Map<String,String[]> params) throws SQLException,Exception;
}