package org.ez.crud;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

//非线程安全
/**
 * @author Jaon
 * CRUD是数据库基本操作接口，提供数据最基本的增删改查操作
 * 并把数据库返回的关系类型的操作结果转换成为java对象（Map类型或者List）
 * 
 */
public interface CRUD {
	public CRUD setCon(Connection con);

	public Connection getCon();

	public List<Map<String, Object>> query(String sql, Object... params)
			throws SQLException, Exception;

	public List<Map<String, Object>> query(String sql) throws SQLException,
			Exception;

	public Map<String, Object> queryOne(String sql, Object... params) throws SQLException,
			Exception;

	public Map<String, Object> queryOne(String sql) throws SQLException, Exception;

	public int update(String sql, Object... params) throws SQLException,
			Exception;

	public int update(String sql) throws SQLException, Exception;

	public int insert(String sql, Object... params) throws SQLException,
			Exception;

	public int insert(String sql) throws SQLException, Exception;

	public int delete(String sql, Object... params) throws SQLException,
			Exception;

	public int delete(String sql) throws SQLException,
			Exception;
}
