package org.ez.crud;

public class Privilege {
	public static int LEADER = 0;
	public static int ADMIN = 1;
	public static int STAFF = 2;
}
