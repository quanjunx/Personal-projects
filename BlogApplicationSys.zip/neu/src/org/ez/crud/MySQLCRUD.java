package org.ez.crud;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

public class MySQLCRUD implements CRUD {
	Connection con;

	@Override
	public CRUD setCon(Connection con) {
		this.con = con;
		return this;
	}

	@Override
	public Connection getCon() {
		return con;
	}

	@Override
	public List<Map<String, Object>> query(String sql, Object... params)
			throws SQLException, Exception {
		List<Map<String, Object>> result = new QueryRunner().query(con, sql,
				new MapListHandler(), params);
		return result;
	}

	@Override
	public List<Map<String, Object>> query(String sql) throws SQLException,
			Exception {
		List<Map<String, Object>> result = new QueryRunner().query(con, sql,
				new MapListHandler());
		return result;
	}

	@Override
	public Map<String, Object> queryOne(String sql, Object... params)
			throws SQLException, Exception {
		Map<String, Object> result = new QueryRunner().query(con, sql,
				new MapHandler(), params);
		return result;
	}

	@Override
	public Map<String, Object> queryOne(String sql) throws SQLException,
			Exception {
		Map<String, Object> result = new QueryRunner().query(con, sql,
				new MapHandler());
		return result;
	}

	@Override
	public int update(String sql, Object... params) throws SQLException,
			Exception {
		int rows = new QueryRunner().update(con, sql, params);
		return rows;
	}

	@Override
	public int update(String sql) throws SQLException, Exception {
		int rows = new QueryRunner().update(con, sql);
		return rows;
	}

	@Override
	public int insert(String sql, Object... params) throws SQLException,
			Exception {
		int rows = new QueryRunner().update(con, sql, params);
		return rows;
	}

	@Override
	public int insert(String sql) throws SQLException, Exception {
		int rows = new QueryRunner().update(con, sql);
		return rows;
	}

	@Override
	public int delete(String sql, Object... params) throws SQLException,
			Exception {
		int rows = new QueryRunner().update(con, sql, params);
		return rows;
	}

	@Override
	public int delete(String sql) throws SQLException, Exception {
		int rows = new QueryRunner().update(con, sql);
		return rows;
	}
}
