package org.ez.data;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.ez.crud.Privilege;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.c3p0.DataSources;

public class MySQLConnectionFactory implements ConnectionFactory {
	DataSource ds4admin, ds4staff, ds4leader;

	public MySQLConnectionFactory() {
		ComboPooledDataSource admin = new ComboPooledDataSource();
		ComboPooledDataSource staff = new ComboPooledDataSource();
		ComboPooledDataSource leader = new ComboPooledDataSource();
		try {
			admin.setDriverClass("com.mysql.jdbc.Driver"); // loads the jdbc
															// driver4admin
			admin.setJdbcUrl("jdbc:mysql://localhost/s");
			admin.setUser("root");
			admin.setPassword("123");

			staff.setDriverClass("com.mysql.jdbc.Driver"); // loads the jdbc
															// driver4staff
			staff.setJdbcUrl("jdbc:mysql://localhost/s");
			staff.setUser("root");
			staff.setPassword("123");
			staff.setMaxStatements( 180 );
			staff.setMinPoolSize(5);                                     
			staff.setAcquireIncrement(5);
			staff.setMaxPoolSize(20);

			leader.setDriverClass("com.mysql.jdbc.Driver"); // loads the jdbc
															// driver4admin
			leader.setJdbcUrl("jdbc:mysql://localhost/s");
			leader.setUser("root");
			leader.setPassword("123");

			ds4admin = admin;
			ds4staff = staff;
			ds4leader = leader;
		} catch (Exception e) {
			System.out.println("init datasource failure");
			e.printStackTrace();
		}
	}

	@Override
	public Connection getConnection(int privilige) throws SQLException,
			Exception {
		if(privilige == Privilege.STAFF){
			return ds4staff.getConnection();
		}else if(privilige == Privilege.LEADER){
			return ds4leader.getConnection();
		}else if(privilige == Privilege.ADMIN){
			return ds4admin.getConnection();
		}
		throw new SQLException("no such priviledge");
	}

	@Override
	public void closeConnectionFactory() throws SQLException, Exception {
		DataSources.destroy( ds4staff );
		DataSources.destroy( ds4leader );
		DataSources.destroy( ds4admin );
	}

}
