package org.ez.data;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author Jason
 * ConnectionFactory是生产Connection的抽象工厂接口
 * 集中管理Connection的产生
 * 其中getConnection 方法就是用来从工厂中获取连接的方法。
 * 所有能够提供Connection的类都必须实现此接口
 */
public interface ConnectionFactory {
	//privilege 是常量，在org.ez.util.Privilege类中定义
	public Connection getConnection(int privilige) throws SQLException,Exception;
	public void closeConnectionFactory() throws SQLException,Exception;
}