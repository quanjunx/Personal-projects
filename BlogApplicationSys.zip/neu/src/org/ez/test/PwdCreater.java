package org.ez.test;

import org.jasypt.util.password.BasicPasswordEncryptor;

public class PwdCreater {
	public static void main(String[] args) {
		BasicPasswordEncryptor passwordEncryptor = new BasicPasswordEncryptor();
		String encryptedPassword = passwordEncryptor
				.encryptPassword("123456");
		System.out.println(encryptedPassword);
	}
}
