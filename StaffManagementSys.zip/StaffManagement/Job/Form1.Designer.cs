﻿namespace Job
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dv = new System.Windows.Forms.DataGridView();
            this.查询 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dept = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.job = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.staffshow = new System.Windows.Forms.Button();
            this.staff = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.view = new System.Windows.Forms.Button();
            this.upload = new System.Windows.Forms.Button();
            this.photopath = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.quit = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.hiredate = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.sal = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.deptno = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.mgr = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ejob = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.ename = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.eid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.inputsql = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.flush = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dv)).BeginInit();
            this.查询.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(981, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // dv
            // 
            this.dv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dv.Location = new System.Drawing.Point(8, 81);
            this.dv.Name = "dv";
            this.dv.RowTemplate.Height = 23;
            this.dv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dv.Size = new System.Drawing.Size(668, 208);
            this.dv.TabIndex = 1;
            this.dv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dv_CellContentClick);
            // 
            // 查询
            // 
            this.查询.Controls.Add(this.button1);
            this.查询.Controls.Add(this.dept);
            this.查询.Controls.Add(this.label4);
            this.查询.Controls.Add(this.job);
            this.查询.Controls.Add(this.label3);
            this.查询.Controls.Add(this.id);
            this.查询.Controls.Add(this.label2);
            this.查询.Controls.Add(this.name);
            this.查询.Controls.Add(this.label1);
            this.查询.Location = new System.Drawing.Point(756, 81);
            this.查询.Name = "查询";
            this.查询.Size = new System.Drawing.Size(213, 219);
            this.查询.TabIndex = 2;
            this.查询.TabStop = false;
            this.查询.Text = "查询";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(71, 168);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 27);
            this.button1.TabIndex = 8;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dept
            // 
            this.dept.Location = new System.Drawing.Point(71, 132);
            this.dept.Name = "dept";
            this.dept.Size = new System.Drawing.Size(113, 21);
            this.dept.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "部门";
            // 
            // job
            // 
            this.job.FormattingEnabled = true;
            this.job.Items.AddRange(new object[] {
            "Staff",
            "Manager",
            "President"});
            this.job.Location = new System.Drawing.Point(71, 94);
            this.job.Name = "job";
            this.job.Size = new System.Drawing.Size(113, 20);
            this.job.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "工作";
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(71, 58);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(113, 21);
            this.id.TabIndex = 3;
            this.id.TextChanged += new System.EventHandler(this.id_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "编号";
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(71, 26);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(113, 21);
            this.name.TabIndex = 1;
            this.name.TextChanged += new System.EventHandler(this.name_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "姓名";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.staffshow);
            this.groupBox1.Controls.Add(this.staff);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.view);
            this.groupBox1.Controls.Add(this.upload);
            this.groupBox1.Controls.Add(this.photopath);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.quit);
            this.groupBox1.Controls.Add(this.delete);
            this.groupBox1.Controls.Add(this.update);
            this.groupBox1.Controls.Add(this.add);
            this.groupBox1.Controls.Add(this.hiredate);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.sal);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.deptno);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.mgr);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.ejob);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.ename);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.eid);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(12, 295);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(681, 216);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "显示信息/修改信息";
            // 
            // staffshow
            // 
            this.staffshow.Location = new System.Drawing.Point(312, 164);
            this.staffshow.Name = "staffshow";
            this.staffshow.Size = new System.Drawing.Size(72, 24);
            this.staffshow.TabIndex = 26;
            this.staffshow.Text = "人数显示";
            this.staffshow.UseVisualStyleBackColor = true;
            this.staffshow.Click += new System.EventHandler(this.staffshow_Click);
            // 
            // staff
            // 
            this.staff.Location = new System.Drawing.Point(285, 126);
            this.staff.Name = "staff";
            this.staff.Size = new System.Drawing.Size(88, 21);
            this.staff.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(221, 129);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 24;
            this.label11.Text = "员工人数";
            // 
            // view
            // 
            this.view.Location = new System.Drawing.Point(544, 168);
            this.view.Name = "view";
            this.view.Size = new System.Drawing.Size(63, 22);
            this.view.TabIndex = 23;
            this.view.Text = "浏览";
            this.view.UseVisualStyleBackColor = true;
            this.view.Click += new System.EventHandler(this.view_Click);
            // 
            // upload
            // 
            this.upload.Location = new System.Drawing.Point(613, 167);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(62, 23);
            this.upload.TabIndex = 22;
            this.upload.Text = "上传";
            this.upload.UseVisualStyleBackColor = true;
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // photopath
            // 
            this.photopath.Location = new System.Drawing.Point(431, 169);
            this.photopath.Name = "photopath";
            this.photopath.Size = new System.Drawing.Size(107, 21);
            this.photopath.TabIndex = 21;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(488, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(121, 146);
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // quit
            // 
            this.quit.Location = new System.Drawing.Point(234, 164);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(72, 24);
            this.quit.TabIndex = 19;
            this.quit.Text = "重置";
            this.quit.UseVisualStyleBackColor = true;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(158, 164);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(70, 24);
            this.delete.TabIndex = 18;
            this.delete.Text = "删除";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // update
            // 
            this.update.Location = new System.Drawing.Point(86, 164);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(66, 25);
            this.update.TabIndex = 17;
            this.update.Text = "修改";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(16, 164);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(64, 24);
            this.add.TabIndex = 16;
            this.add.Text = "新增";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // hiredate
            // 
            this.hiredate.Location = new System.Drawing.Point(82, 126);
            this.hiredate.Name = "hiredate";
            this.hiredate.Size = new System.Drawing.Size(110, 21);
            this.hiredate.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 129);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 14;
            this.label12.Text = "HIREDATE";
            // 
            // sal
            // 
            this.sal.Location = new System.Drawing.Point(259, 89);
            this.sal.Name = "sal";
            this.sal.Size = new System.Drawing.Size(114, 21);
            this.sal.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(221, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 12);
            this.label10.TabIndex = 10;
            this.label10.Text = "SAL";
            // 
            // deptno
            // 
            this.deptno.Location = new System.Drawing.Point(83, 89);
            this.deptno.Name = "deptno";
            this.deptno.Size = new System.Drawing.Size(109, 21);
            this.deptno.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Location = new System.Drawing.Point(27, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "DEPTNO";
            // 
            // mgr
            // 
            this.mgr.Location = new System.Drawing.Point(259, 51);
            this.mgr.Name = "mgr";
            this.mgr.Size = new System.Drawing.Size(114, 21);
            this.mgr.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(221, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 12);
            this.label8.TabIndex = 6;
            this.label8.Text = "MGR";
            // 
            // ejob
            // 
            this.ejob.Location = new System.Drawing.Point(82, 51);
            this.ejob.Name = "ejob";
            this.ejob.Size = new System.Drawing.Size(109, 21);
            this.ejob.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 4;
            this.label7.Text = "EJOB";
            // 
            // ename
            // 
            this.ename.Location = new System.Drawing.Point(259, 17);
            this.ename.Name = "ename";
            this.ename.Size = new System.Drawing.Size(114, 21);
            this.ename.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(221, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "ENAME";
            // 
            // eid
            // 
            this.eid.Location = new System.Drawing.Point(82, 17);
            this.eid.Name = "eid";
            this.eid.Size = new System.Drawing.Size(110, 21);
            this.eid.TabIndex = 1;
            this.eid.TextChanged += new System.EventHandler(this.eid_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "EID";
            // 
            // inputsql
            // 
            this.inputsql.Location = new System.Drawing.Point(699, 315);
            this.inputsql.Multiline = true;
            this.inputsql.Name = "inputsql";
            this.inputsql.Size = new System.Drawing.Size(270, 135);
            this.inputsql.TabIndex = 4;
            this.inputsql.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(798, 464);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 28);
            this.button2.TabIndex = 5;
            this.button2.Tag = "";
            this.button2.Text = "执行sql";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // flush
            // 
            this.flush.Location = new System.Drawing.Point(691, 152);
            this.flush.Name = "flush";
            this.flush.Size = new System.Drawing.Size(56, 42);
            this.flush.TabIndex = 6;
            this.flush.Text = "刷新";
            this.flush.UseVisualStyleBackColor = true;
            this.flush.Click += new System.EventHandler(this.flush_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 514);
            this.Controls.Add(this.flush);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.inputsql);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.查询);
            this.Controls.Add(this.dv);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "职员管理系统";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dv)).EndInit();
            this.查询.ResumeLayout(false);
            this.查询.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dv;
        private System.Windows.Forms.GroupBox 查询;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox job;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox dept;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox ejob;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ename;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox eid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox mgr;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox deptno;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox hiredate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox sal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox inputsql;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button upload;
        private System.Windows.Forms.TextBox photopath;
        private System.Windows.Forms.Button view;
        private System.Windows.Forms.Button flush;
        private System.Windows.Forms.TextBox staff;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button staffshow;
    }
}

