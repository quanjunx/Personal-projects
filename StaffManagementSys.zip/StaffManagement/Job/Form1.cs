﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OracleClient;


namespace Job
{
    public partial class Form1 : Form
    {

        String photo;
        public Form1()
        {
            InitializeComponent();
            
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            DBConnection.Query("SELECT * FROM(SELECT A.*,ROWNUM RN FROM(SELECT * FROM Employee) A WHERE ROWNUM <=10) WHERE RN >=0 ORDER BY EID",dv);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String sql1 = "select * from Employee";
            StringBuilder s1 = new StringBuilder(sql1);
            if (id.Text != "")
            {
                s1.Append(" Where EID = '");
                s1.Append(id.Text);
                s1.Append("'");
            }
            //一个查询条件(无员工编号)
            if(id.Text == "" && name.Text != "" && job.Text =="" && dept.Text==""){
                s1.Append(" Where ENAME = '");
                s1.Append(name.Text);
                s1.Append("'");
            }
            if (id.Text == "" && name.Text == "" && job.Text != "" && dept.Text == "")
            {
                s1.Append(" Where EJOB = '");
                s1.Append(job.Text);
                s1.Append("'");
            }
            if (id.Text == "" && name.Text == "" && job.Text == "" && dept.Text != "")
            {
                s1.Append(" Where DEPTNO = '");
                s1.Append(dept.Text);
                s1.Append("'");
            }
            //两个查询条件(无员工编号)
            if (id.Text == "" && name.Text != "" && job.Text != "" && dept.Text == "")
            {
                s1.Append(" Where ENAME = '");
                s1.Append(name.Text);
                s1.Append("' AND EJOB = '");
                s1.Append(job.Text);
                s1.Append("'");
            }
            if (id.Text == "" && name.Text != "" && job.Text == "" && dept.Text != "")
            {
                s1.Append(" Where ENAME = '");
                s1.Append(name.Text);
                s1.Append("' AND DEPTNO = '");
                s1.Append(dept.Text);
                s1.Append("'");
            }
            if (id.Text == "" && name.Text == "" && job.Text != "" && dept.Text != "")
            {
                s1.Append(" Where EJOB = '");
                s1.Append(job.Text);
                s1.Append("' AND DEPTNO = '");
                s1.Append(dept.Text);
                s1.Append("'");
            }
            //三个查询条件(无员工编号)
            if (id.Text == "" && name.Text != "" && job.Text != "" && dept.Text != "")
            {
                s1.Append(" Where ENAME = '");
                s1.Append(name.Text);
                s1.Append("' AND EJOB = '");
                s1.Append(job.Text);
                s1.Append("' AND DEPTNO = '");
                s1.Append(dept.Text);
                s1.Append("'");
            }
            
            if (id.Text == "" && name.Text == "" && job.Text == "" && dept.Text == "")
            {
                MessageBox.Show("请输入至少一个查询条件！");
            }
            String sql = s1.ToString();
            DBConnection.Query(sql, dv);
        }

        private void id_TextChanged(object sender, EventArgs e)
        {

        }

        private void name_TextChanged(object sender, EventArgs e)
        {

        }
        //数据重置
        private void quit_Click(object sender, EventArgs e)
        {
            eid.Text = "";
            ename.Text = "";
            ejob.Text = "";
            mgr.Text = "";
            deptno.Text = "";
            sal.Text = "";
            hiredate.Text = "";
        }

        private void eid_TextChanged(object sender, EventArgs e)
        {

        }

        private void dv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            eid.Text = dv.SelectedRows[0].Cells[0].Value.ToString().Trim();
            ename.Text = dv.SelectedRows[0].Cells[1].Value.ToString().Trim();
            ejob.Text = dv.SelectedRows[0].Cells[2].Value.ToString().Trim();
            mgr.Text = dv.SelectedRows[0].Cells[7].Value.ToString().Trim();
            deptno.Text = dv.SelectedRows[0].Cells[4].Value.ToString().Trim();
            sal.Text = dv.SelectedRows[0].Cells[3].Value.ToString().Trim();
            hiredate.Text = dv.SelectedRows[0].Cells[6].Value.ToString().Trim();
            PreviewImage(dv.SelectedRows[0].Cells[0].Value.ToString().Trim());
          
        }
        //浏览图片
        private void view_Click(object sender, EventArgs e)
        {
            OpenFileDialog filedialog = new OpenFileDialog();
            filedialog.FilterIndex = 1;


            filedialog.Filter = "jpg files (*.jpg)|*.jpg|All files (*.*)|*.*";
            if (filedialog.ShowDialog() == DialogResult.OK)
            {
                photo = filedialog.FileName;
                photopath.Text = filedialog.FileName;
            }

        }
        /*
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            //获得上传图片的二进制信息 
            byte[] buffer = File.ReadAllBytes(photo);

            string name = dv.SelectedRows[0].Cells[0].Value.ToString().Trim();
            string sql = " update Employee set PHOTO = :image where EID = '" + dv.SelectedRows[0].Cells[0].Value.ToString().Trim() + "'";


            using (OracleConnection conn = DBConnection.getConnection())
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(sql, conn);
                cmd.Parameters.Add(":image", OracleType.Blob);
                cmd.Parameters[":image"].Value = buffer;
                cmd.ExecuteNonQuery();
            }
            PreviewImage(name);
            Cursor.Current = Cursors.Default;


            MessageBox.Show("上传成功！");


        }*/
         

        /// <summary> 
        /// 预览图像信息：从数据库读图片信息 
        /// </summary> 
        /// <param name="name"></param> 
        private void PreviewImage(string name)
        {
            //ISDApp01.ISDApp01 isd = new ImageDemo.ISDApp01.ISDApp01();

            string sql = "select PHOTO from Employee where EID='" + name + "'";

            using (OracleConnection conn = DBConnection.getConnection())
            {
                conn.Open();

                OracleCommand cmd = new OracleCommand(sql, conn);

                //获得数据信息并转换成二进制 
                byte[] fileData = cmd.ExecuteScalar() as byte[];
                if (fileData == null)
                {
                    pictureBox1.Image = null;
                    MessageBox.Show("图片还未上传！");
                    return;
                }
                else
                {
                    MemoryStream ms = new MemoryStream(fileData);

                    //把二进制信息转换成image并show出 
                    Image image = Image.FromStream(ms);
                    pictureBox2.Image = image;
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void upload_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            //获得上传图片的二进制信息 
            byte[] buffer = File.ReadAllBytes(photo);

            string name = dv.SelectedRows[0].Cells[0].Value.ToString().Trim();
            string sql = " update Employee set PHOTO = :image where EID = '" + dv.SelectedRows[0].Cells[0].Value.ToString().Trim() + "'";


            using (OracleConnection conn = DBConnection.getConnection())
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(sql, conn);
                cmd.Parameters.Add(":image", OracleType.Blob);
                cmd.Parameters[":image"].Value = buffer;
                cmd.ExecuteNonQuery();
            }
            PreviewImage(name);
            Cursor.Current = Cursors.Default;


            MessageBox.Show("上传成功！");

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
        //向表中插入一条数据
        private void add_Click(object sender, EventArgs e)
        {
            try
            {
                if (ename.Text == "")
                {
                    MessageBox.Show("员工名不能为空！");
                }
                /*
                if (eid.Text != "" || ename.Text != "" && ejob.Text == "" && sal.Text == "" && deptno.Text == "" && hiredate.Text == "" && mgr.Text == "")
                {
                    String sqlinsert = "insert into Employee(EID,ENAME) values('" + eid.Text + "','" + ename.Text + "')";

                    int i = DBConnection.SqlExecute(sqlinsert);
                    if (i > 0)
                    {
                        MessageBox.Show("insert successfully!");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("insert failed!");
                    }
                }
                if (eid.Text != "" || ename.Text != "" && ejob.Text != "" && sal.Text == "" && deptno.Text != "" && hiredate.Text == "" && mgr.Text != "")
                {
                    String sqlinsert = "insert into Employee(EID,ENAME,EJOB,DEPTNO,MGR) values('" + eid.Text + "','" + ename.Text + "','" + ejob.Text + "','" + deptno.Text + "','" + mgr.Text + "')";

                    int i = DBConnection.SqlExecute(sqlinsert);
                    if (i > 0)
                    {
                        MessageBox.Show("insert successfully!");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("insert failed!");
                    }
                }*/
                if (ename.Text != "" && ejob.Text != "" && sal.Text != "" && deptno.Text != "" && hiredate.Text != "" && mgr.Text != "")
                {
                    String sqlinsert = "insert into Employee(ENAME,EJOB,SAL,DEPTNO,HIREDATE,MGR) values('" + ename.Text + "','" + ejob.Text + "','" + sal.Text + "','" + deptno.Text +

     "','" + hiredate.Text + "','" + mgr.Text + "')";

                    int i = DBConnection.SqlExecute(sqlinsert);
                    if (i > 0)
                    {
                        MessageBox.Show("insert successfully!");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("insert failed!");
                    }
                }
            }
            catch(Exception exception)
            {
                MessageBox.Show("您输入的数据类型有误，无法插入数据库，请验证后重新输入！");
            }
           
        }
        //从表中删除数据
        private void delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (eid.Text != "")
                {
                    String sqldel = "delete from Employee where EID=" + eid.Text;
                    int i = DBConnection.SqlExecute(sqldel);
                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully!");
                    }
                    else
                    {
                        MessageBox.Show("delete failed!");
                    }
                }
                if (eid.Text == "" && ename.Text != "")
                {
                    String sqldel = "delete from Employee where ENAME='" + ename.Text + "'";
                    int i = DBConnection.SqlExecute(sqldel);
                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully!");
                    }
                    else
                    {
                        MessageBox.Show("failed!");
                    }
                }
                if (eid.Text == "" && deptno.Text != "")
                {
                    String sqldel = "delete from Employee where DEPTNO=" + deptno.Text;
                    int i = DBConnection.SqlExecute(sqldel);
                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully!");
                    }
                    else
                    {
                        MessageBox.Show("failed!");
                    }
                }
            }
            catch(Exception exception)
            {
                MessageBox.Show("您指定的删除条件不存在，请查证后重新输入！");
            }

        }
        //修改表中的一条数据
        private void update_Click(object sender, EventArgs e)
        {
            try
            {
                String sqlupdate = "update Employee set EID  = '" + eid.Text + "',ENAME = '" + ename.Text + "',EJOB = '" + ejob.Text + "',SAL = '" + sal.Text + "',DEPTNO = '" + deptno.Text + "',HIREDATE = '" + hiredate.Text + "',MGR = '" + mgr.Text + "' where EID = '" + eid.Text + "'";
                int i = DBConnection.SqlExecute(sqlupdate);
                if (i > 0)
                {
                    MessageBox.Show("update successfully!");
                }
                else
                {
                    MessageBox.Show("update failed!");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("您提交的数据类型有误，请输入数值类型！");
            }
        }
        //执行sql脚本
        private void button2_Click(object sender, EventArgs e)
        {
            String sqlscript = inputsql.Text;
            DBConnection.Query(sqlscript, dv);

        }

        private void flush_Click(object sender, EventArgs e)
        {
            DBConnection.Query("SELECT * FROM(SELECT A.*,ROWNUM RN FROM(SELECT * FROM Employee) A WHERE ROWNUM <=10) WHERE RN >=0 ORDER BY EID ASC", dv);
            eid.Text = "";
            ename.Text = "";
            ejob.Text = "";
            mgr.Text = "";
            deptno.Text = "";
            sal.Text = "";
            hiredate.Text = "";
            
            
        }

        private void staffshow_Click(object sender, EventArgs e)
        {
            OracleConnection conn = DBConnection.getConnection();
            conn.Open();
            OracleCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "EMP_COUNT";
            cmd.Parameters.Add("counts", OracleType.Number).Direction = ParameterDirection.Output;//指明传入的参数是输入给oracle存储过程用的
            //cmd.Parameters[""].Value = textBox4.Text.Trim();
            //cmd.Parameters.Add("sal_factor", OracleType.Number).Direction = ParameterDirection.Input;//指明传入的参数是输入给oracle存储过程用的
            //cmd.Parameters["sal_factor"].Value = textBox9.Text.Trim();
            int i = cmd.ExecuteNonQuery();
            staff.Text = cmd.Parameters["counts"].Value.ToString();
        }
       
  

    }
}
