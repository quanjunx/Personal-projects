﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OracleClient;
using System.Windows.Forms;
using System.Data;

namespace Job
{
    class DBConnection
    {
        private static DataTable dt;
        static String ConnStr = "Data Source=orcl_client; User ID=xiaquanjun; Password=xiaquanjun;";
        public static OracleConnection conn = new OracleConnection(ConnStr);
        public static OracleConnection getConnection()
        {
            OracleConnection conn = new OracleConnection(ConnStr);
            return conn;
        }
        //重载的查询方法Query
        public static DataTable Query(String sql)
        {
            OracleDataAdapter adapter = new OracleDataAdapter(sql, conn);
            dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }
        public static void Query(String sql, DataGridView dv)
        {

            OracleDataAdapter adapter = new OracleDataAdapter(sql, conn);
            OracleCommandBuilder build = new OracleCommandBuilder(adapter);
            dt = new DataTable();
            adapter.Fill(dt);
            dv.DataSource = dt;
            conn.Close();
        }
        //执行DML操作
        public static int SqlExecute(String sql)
        {
            int k;
            conn.Open();
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            k = cmd.ExecuteNonQuery();
            return k;
        }

        public static void getInfo(String sql, ComboBox box)
        {

            conn.Open();
            OracleCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            OracleDataReader rs = cmd.ExecuteReader();
            while (rs.Read())
            {
                box.Items.Add(rs.GetValue(0));
            }
            rs.Close();
            conn.Close();
            if (box.Items.Count != 0)
                box.SelectedIndex = 0;
        }



       
    }
}
